using static System.Windows.Forms.LinkLabel;

namespace csillagterkep
{
    public partial class Form1 : Form
    {
        Models.HajosContext hajosContext = new Models.HajosContext();
        
        public Form1()
        {
            InitializeComponent();
            
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            var stars = (from s in hajosContext.StarData select new { s.Hip, s.X, s.Y, s.Magnitude }).ToList();
           
            Graphics g = this.CreateGraphics();

            g.Clear(Color.DarkBlue);
            Color c = Color.White;

            Pen toll = new Pen(c, 1);
            Brush brush = new SolidBrush(c);
            double nagyitas= 300;
            float cx = ClientRectangle.Width / 2;
            float cy = ClientRectangle.Height / 2;

            foreach (var s in stars)
            {
                
                if(s.Magnitude > 6) continue;
                if (Math.Sqrt(Math.Pow(s.X, 2) + Math.Pow(s.Y, 2)) > 1) continue;


                double size = 20 * Math.Pow(10, (s.Magnitude) / -2.5);
                

                float x =(float)( s.X * nagyitas+cx);
                float y = (float)(s.Y * nagyitas+cy);

                float radius = (float)size / 2; 

               
                g.FillEllipse(brush, x - radius, y - radius, radius * 2, radius * 2);


            }
            var lines = hajosContext.ConstellationLines.ToList();
            foreach (var line in lines)
            {
                var star1 = (from x in stars
                             where x.Hip == line.Star1
                             select x).FirstOrDefault();

                var star2 = (from y in stars
                             where y.Hip == line.Star2
                             select y).FirstOrDefault();




                if (star1 == null || star2 == null) continue;
                
                    float star1X = (float)(star1.X * nagyitas + cx);
                    float star1Y = (float)(star1.Y * nagyitas + cy);

                    float star2X = (float)(star2.X * nagyitas + cx);
                    float star2Y = (float)(star2.Y * nagyitas + cy);
                    g.DrawLine(toll, star1X, star1Y, star2X, star2Y);
                
            }





        }
    }
}
