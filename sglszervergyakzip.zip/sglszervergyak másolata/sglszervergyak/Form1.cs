namespace sglszervergyak
{
    public partial class Form1 : Form
    {
        Models.StudentContext studentContext = new Models.StudentContext();
        public Form1()
        {
            InitializeComponent();
            studentBindingSource.DataSource = studentContext.Students.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                studentContext.SaveChanges();
            }
            catch (Exception kiv�tel)
            {
                MessageBox.Show(kiv�tel.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string sz�veg = textBox1.Text.ToLower();

            var eredmeny = from s in studentContext.Students
                           where s.Name.ToLower().StartsWith(sz�veg)
                           select s;

            studentBindingSource.DataSource = eredmeny.ToList();
        }
    }
}
