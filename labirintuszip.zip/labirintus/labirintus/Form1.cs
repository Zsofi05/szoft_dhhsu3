using System.Diagnostics;
using Timer = System.Windows.Forms.Timer;

namespace labirintus
{
    public partial class Form1 : Form
    {
        // v�ltoz�k
        int valtozo = 20;
        int stepCount = 0;
        int elapsedTime = 0;

        // oszt�ly p�ld�nyos�t�sok

        PictureBox jatekos;
        List<PictureBox> bricks = new List<PictureBox>();
        Label stepCountLabel = new Label();
        Timer timer = new Timer();
        Label timeLabel = new Label();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // label-ek tulajdons�gai �s kirak�suk

            timeLabel.Top = 20;
            timeLabel.Left = 1230;
            timeLabel.Width = 200;
            timeLabel.BackColor = Color.Beige;

            stepCountLabel.Top = 0;
            stepCountLabel.Left = 1230;
            stepCountLabel.Width = 200;
            stepCountLabel.BackColor=Color.Beige;

            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start();

            Controls.Add(stepCountLabel);
            Controls.Add(timeLabel);

            // labirintus f�jl megnyit�sa

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files (*.txt)|*.txt";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamReader sr = new StreamReader(openFileDialog.FileName);
                    int sor = 0;
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        for (int oszlop = 0; oszlop < line.Length; oszlop++)
                        {
                            if (line[oszlop] == '#')
                            {
                                PictureBox pictureBox = new PictureBox();
                                pictureBox.Top = sor * valtozo;
                                pictureBox.Left = oszlop * valtozo;
                                pictureBox.Width = valtozo;
                                pictureBox.Height = valtozo;
                                pictureBox.BackColor = Color.Black;

                                Controls.Add(pictureBox);
                                bricks.Add(pictureBox);
                            }
                        }
                        sor++;
                    }
                    sr.Close();


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hiba t�rt�nt: " + ex.Message);
                }
            }

            // rendszer�zenetek

            MessageBox.Show("A teljes j�t�k�lm�ny �rdek�ben �rdemes teljes k�perny�n j�tszani. ;)");
            MessageBox.Show("A j�t�kost a nyilakkal, illetve a w-a-s-d gombokkal lehet �r�ny�tani. A j�tok �jrakezd�se az R gomb lenyom�s�val lehets�ges.");


            // j�t�kos kirajzol�sa

            jatekos = new PictureBox();
            jatekos.Height = valtozo;
            jatekos.Width = valtozo;
            jatekos.BackColor = Color.Red;


            Controls.Add(jatekos);

            this.KeyDown += Form1_KeyDown;
        }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            this.Focus();
           
            int x = jatekos.Left;
            int y = jatekos.Top;

            // a bet�k haszn�lat�ak --> balkezeseknek k�nnyebb

            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
            {
                x -= valtozo;
            }
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
            {
                x += valtozo;
            }
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.W)
            {
                y -= valtozo;
            }
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.S)
            {
                y += valtozo;
            }
            if (e.KeyCode == Keys.R)
            {
                y = 0;
                x = 0;
                stepCount = -1;
               


            }

            // vannak m�r ott ahova rakni szeretn�k?

            var brick = (from s in bricks
                         where s.Left == x && s.Top == y
                         select s).FirstOrDefault();
            if (brick == null)
            {
                jatekos.Left = x;
                jatekos.Top = y;
                stepCount++;
                stepCountLabel.Text = "L�p�sek: " + stepCount;
               

            }
           
        }

        // az id� m�r�se, fontos berakni a legelej�re: using Timer = System.Windows.Forms.Timer;

        private void Timer_Tick(object sender, EventArgs e)
        {
            elapsedTime++;
            timeLabel.Text = "Id�: " + TimeSpan.FromSeconds(elapsedTime).ToString(@"hh\:mm\:ss");
        }




    }
}
