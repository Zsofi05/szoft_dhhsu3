﻿using studies_adatbázis.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Formats.Asn1;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace studies_adatbázis
{
    public partial class UserControl3 : UserControl
    {
        StudiesContext context = new StudiesContext();
        public UserControl3()
        {
            InitializeComponent();

        }


        private void UserControl3_Load(object sender, EventArgs e)
        {
            var query = from i in context.Instructors
                        select new
                        {
                            i.Name,
                            Státusz = i.StatusFkNavigation.Name,
                           Állás = i.EmployementFkNavigation.Name
                        };
            dataGridView1.DataSource = query.ToList();


        }

        //private void button1_Click(object sender, EventArgs e)
        //{
            //using (StreamWriter file = new StreamWriter(filePath))
            //{
               // file.WriteLine("Name,Státusz,Állás"); // CSV Header
               // foreach (var instructor in query)
               // {
               //     file.WriteLine($"{instructor.InstructorSk},{instructor.Name},{instructor.Status},{instructor.EmploymentType}");
                //}
            //}
           // MessageBox.Show($"Data saved to {filePath}");
        //}
    }
}
